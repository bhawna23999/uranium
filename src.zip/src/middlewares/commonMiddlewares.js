

const middleWare = async function(req,res,next) 
{
    const headerVal= req.headers.isfreeappuser
    // console.log(headerVal)
    
    if(headerVal)
    {
        if(headerVal==true) 
        req['isFreeAppUser'] = true
               
        if(headerVal==false)        
        req['isFreeAppUser'] = false       
        
        next()
                      
    }
    else
    {
        res.send({Error:"request is missing a mandatory header"})

    }
}

module.exports.middleWare = middleWare

