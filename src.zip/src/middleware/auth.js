const jwt = require("jsonwebtoken")
const mongoose = require('mongoose')
const MW = async function(req,res,next)
{
    
    
    let userId = req.params.userId
    if(!mongoose.isValidObjectId(userId)) 
    return res.send({msg: "Incorrect Id"})

    let token = req.headers['x-Auth-Token'] || req.headers['x-auth-token']
    

    if(token)
    {
        next()
    }
    else
    {
        res.send({msg:"token must"})
    }

  
}    

module.exports.MW = MW