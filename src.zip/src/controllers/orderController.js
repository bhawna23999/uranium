const productModel = require("../models/productModel")
const userModel = require("../models/userModel")
const orderModel = require("../models/orderModel")

const createuserOrders = async function(req,res)
{
    let orders = req.body
    let getPId = req.body.productId
    let getUId = req.body.userId
    if(!getPId && !getUId)
    {
        return res.send({Error:"Product Id and User is is required"})
    }
    if(!getPId)
    {
        return res.send({Error:"Produt Id is required"})
    }
    if(!getUId)
    {
        return res.send({Error:"User Id is required"})
    }
    let userbalance = await user.findOne({_id: req.body.userId}).select('balance')
    let productPrince = await product.findOne({_id: req.body.productId}).select('price')
    if(!freeUser && userbalance.balance >= productPrince.price){
        let newBalance = userbalance.balance - productPrince.price
        let orderData = await order.create({
            userId: req.body.userId,
            productId: req.body.productId,
            amount: productPrince.price,
            isFreeAppUser: false
        })
        await user.findOneAndUpdate({_id: req.body.userId}, {balance: newBalance})
        res.send({msg: orderData})
    }
    if(!freeUser && userbalance.balance < productPrince.price) return res.send({msg: "insufficient balance"})
    if(freeUser){
        let orderData = await order.create({
            userId: req.body.userId,
            productId: req.body.productId,
            amount: 0,
            isFreeAppUser: true
        })
        res.send({msg: orderData})
    }

}



const getOrderData = async function(req,res)
{
    let getOrder = await orderModel.find()
    res.send({data:getOrder})
}

const getDatawithUserAndProductDetails = async function(req,res)
{
    let getAllData = await orderModel.find().populate('userId productId')
    res.send({data:getAllData})
}
module.exports.createuserOrders = createuserOrders
module.exports.getOrderData = getOrderData
module.exports.getDatawithUserAndProductDetails = getDatawithUserAndProductDetails